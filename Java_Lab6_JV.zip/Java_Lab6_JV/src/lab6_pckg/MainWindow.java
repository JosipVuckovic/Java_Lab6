package lab6_pckg;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.SpringLayout;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Button;
import java.awt.Dimension;

@SuppressWarnings({ "serial", "unused" })
public class MainWindow extends JFrame {

	private JPanel contentPane;
	private JTextField textInput;
	public JTextArea textArea;
	private static final Logger log = LoggerFactory.getLogger(JFrame.class);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {					
					MainWindow frame = new MainWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainWindow() {
		log.trace("Main Enter");
		log.debug("Main Enter");
		log.info("Main Enter");
		log.warn("Main Enter");
		log.trace("try connect");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 504, 352);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);

		JButton btnSend = new JButton("Send");
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnSend, -5, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnSend, -5, SpringLayout.EAST, contentPane);
		contentPane.add(btnSend);

		textInput = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.WEST, textInput, 5, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, textInput, -5, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, textInput, -5, SpringLayout.WEST, btnSend);
		contentPane.add(textInput);
		textInput.setColumns(10);

		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		sl_contentPane.putConstraint(SpringLayout.EAST, textArea, 0, SpringLayout.EAST, textInput);
		sl_contentPane.putConstraint(SpringLayout.NORTH, textInput, 6, SpringLayout.SOUTH, textArea);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, textArea, -6, SpringLayout.NORTH, btnSend);
		sl_contentPane.putConstraint(SpringLayout.NORTH, textArea, 5, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, textArea, 5, SpringLayout.WEST, contentPane);
		contentPane.add(textArea);

		btnSend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText(textInput.getText());
				send();
				textInput.setText("\0");			
			}
		});

		textInput.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {

					textArea.setText(textInput.getText());
					textArea.setText("\0");
				}

			}
		});		
		
		connect();		
	}
	
	Socket soc;
	PrintWriter pw;
	BufferedReader br;

	
	private void connect() {
		try {
			log.debug("Now in connect");
			soc = new Socket(UserConfig.getHost(), Integer.parseInt(UserConfig.getPort()));
			pw = new PrintWriter(soc.getOutputStream());
			br = new BufferedReader(new InputStreamReader(soc.getInputStream()));
			String response;
			try {
				log.debug("try block in connect starting");
				response = br.readLine();				
				if (textArea.getText().length() > 0)				 	
					textArea.append("\n");				
				textArea.append(response);
				textInput.setText(null);	
				log.debug("try block in connect ending");				 
			} catch (IOException e) {
				log.debug("Error in connect");
				log.error("Greška kod čitanja inicijalnog odgovora", e);
				JOptionPane.showMessageDialog(textArea, "Greška kod čitanja inicijalnog odgovora", "Greška!",
						JOptionPane.ERROR_MESSAGE);
			}
		} catch (UnknownHostException e) {
			log.error("Nepoznati host", e);
			this.dispose();
		} catch (IOException e) {
			log.error("IO iznimka", e);
			this.dispose();
		}
	}

	private void send() {
		pw.println(textInput.getText());
		if (pw.checkError()) {
			JOptionPane.showMessageDialog(textArea, "Greška kod slanja poruke", "Greška!", JOptionPane.ERROR_MESSAGE);
		}
		String response;
		try {
			response = br.readLine();
			if (textArea.getText().length() > 0)
			 		textArea.append("\n");
			
			textArea.append(response);
			textInput.setText(null);
			 
		} catch (IOException e) {
			log.error("Greška kod čitanja", e);
			JOptionPane.showMessageDialog(textArea, "Greška kod čitanja odgovora", "Greška!",
					JOptionPane.ERROR_MESSAGE);
		}
	}

}
