package lab6_pckg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class UserConfig {
	public static String getHost() {
		return host;
	}

	public static String getPort() {
		return port;
	}

	public static String getKorisnik() {
		return korisnik;
	}
	private static final String propertiesFile = "chat.properties";
	private static final String hostPropertieName = "host";
	private static final String portPropertieName = "port";
	private static final String userPropertieName = "user";
	static   String host;
	static  String port;
	static  String korisnik;
	public static void loadParams() {
		Properties props = new Properties();
		InputStream is = null;
		try {
			File f = new File(propertiesFile);
			is = new FileInputStream(f);
		} catch (Exception e) {
			e.printStackTrace();
			is = null;
		}
		try {
			props.load(is);
		} catch (Exception e) {
		}
		host = props.getProperty(hostPropertieName, "192.168.0.1");
		port = props.getProperty(portPropertieName, "8080");
		korisnik = props.getProperty(userPropertieName, "anonymous");
	}

	public static void saveParamChanges() {
		try {
			Properties props = new Properties();
			props.setProperty(hostPropertieName, host);
			props.setProperty(portPropertieName, "" + port);
			props.setProperty(userPropertieName, korisnik);
			File f = new File(propertiesFile);
			OutputStream out = new FileOutputStream(f);
			props.store(out, "Opcionalni header komentar");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
