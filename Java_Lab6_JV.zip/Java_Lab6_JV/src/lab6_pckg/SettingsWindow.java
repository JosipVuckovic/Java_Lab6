package lab6_pckg;

import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;

@SuppressWarnings({ "serial", "unused" })
public class SettingsWindow extends JFrame {

	private JPanel contentPane;
	private JTextField HostTxt;
	private JTextField PortTxt;
	private JTextField UserTxt;
	private static final Logger log = LoggerFactory.getLogger(JFrame.class);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SettingsWindow frame = new SettingsWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public SettingsWindow() {
		log.trace("Settings Enter");
		log.debug("Settings Enter");
		log.info("Settings Enter");
		log.warn("Settings Enter");
	
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {					
				int confirmed = JOptionPane.showOptionDialog(contentPane, "Exit without saving?", "Warning!",
						JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[] { "Yes", "No" }, "No");
			
				if (JOptionPane.YES_OPTION == confirmed) {
					dispose();
				} else {
					UserConfig.host = HostTxt.getText();
					UserConfig.port = PortTxt.getText();
					UserConfig.korisnik = UserTxt.getText();
					UserConfig.saveParamChanges();
				}

			}

			public void windowOpened(WindowEvent e) {
				UserConfig.loadParams();
				HostTxt.setText(UserConfig.host);
				PortTxt.setText(UserConfig.port);
				UserTxt.setText(UserConfig.korisnik);
			}
		});

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 439, 198);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		HostTxt = new JTextField();
		HostTxt.setBounds(158, 22, 216, 20);
		contentPane.add(HostTxt);
		HostTxt.setColumns(10);

		PortTxt = new JTextField();
		PortTxt.setBounds(158, 53, 216, 20);
		contentPane.add(PortTxt);
		PortTxt.setColumns(10);

		UserTxt = new JTextField();
		UserTxt.setBounds(158, 84, 216, 20);
		contentPane.add(UserTxt);
		UserTxt.setColumns(10);

		JLabel HostLabel = new JLabel("Host: ");
		HostLabel.setBounds(84, 25, 46, 14);
		contentPane.add(HostLabel);

		JLabel PortLabel = new JLabel("Port: ");
		PortLabel.setBounds(84, 56, 46, 14);
		contentPane.add(PortLabel);

		JLabel UserLabel = new JLabel("User: ");
		UserLabel.setBounds(84, 87, 46, 14);
		contentPane.add(UserLabel);
		
		JButton btnCancle = new JButton("Cancle");
		btnCancle.setBounds(287, 125, 89, 23);
		btnCancle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancle.setActionCommand("Cancel");
		contentPane.add(btnCancle);		
		

		JButton btnSave = new JButton("Ok");
		btnSave.setBounds(188, 125, 89, 23);
		contentPane.add(btnSave);
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserConfig.host = HostTxt.getText();
				UserConfig.port = PortTxt.getText();
				UserConfig.korisnik = UserTxt.getText();
				UserConfig.saveParamChanges();
				dispose();	
				new MainWindow().setVisible(true);
			}
		});
		btnSave.setActionCommand("Ok");
		getRootPane().setDefaultButton(btnSave);
		
	}

}
